package com.ashokit.synchronize;

import java.util.concurrent.Callable;

public class ThreadExample1 {
	
	ThreadExample1(Runnable r){
		
	}
	
	ThreadExample1(Callable<Object> r){
		
	}

}
